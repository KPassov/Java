public class Photograph
{
	public Photograph(String[] photograph)
	{
		if (photograph == null)
			photograph = new String[] { };
    // ...
	}

  public int getWidth()
	{
    return 0;
	}

	public int getHeight()
	{
    return 0;
	}

	/**
	 * @null if the index is out of bounds.
	 */
	public String getLine(int index)
	{
		if (index < 0 || index >= this.photograph.length)
			return null;
	  // ...
  }
}
